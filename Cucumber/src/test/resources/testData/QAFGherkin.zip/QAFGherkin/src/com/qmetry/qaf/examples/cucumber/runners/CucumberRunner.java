package com.qmetry.qaf.examples.cucumber.runners;


import java.io.IOException;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.ui.WebDriverTestCase;

import cucumber.api.CucumberOptions;

@CucumberOptions(plugin={"com.qmetry.qaf.examples.cucumber.runners.QAFPerfectoCucumberFormatter"})
public class CucumberRunner extends WebDriverTestCase implements IHookable {
	private QAFTestNGCucumberRunner runner;
	
	@BeforeTest
	public void createRunner(ITestContext contex){
		runner=new QAFTestNGCucumberRunner(getClass(),contex);
	}
	
    @Test(groups = "cucumber", description = "Runs Cucumber Features")
    public void run_cukes() throws IOException {
        runner.runCukes();
    }

    @Override
    public void run(IHookCallBack iHookCallBack, ITestResult iTestResult) {
        iHookCallBack.runTestMethod(iTestResult);
    }
    
    
}