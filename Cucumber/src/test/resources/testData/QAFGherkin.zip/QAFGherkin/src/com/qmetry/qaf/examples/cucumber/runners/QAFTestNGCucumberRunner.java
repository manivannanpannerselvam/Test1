package com.qmetry.qaf.examples.cucumber.runners;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;

import org.testng.ITestContext;

import com.qmetry.qaf.automation.cucumber.QAFCucumberFormatter;

import cucumber.runtime.ClassFinder;
import cucumber.runtime.CucumberException;
import cucumber.runtime.RuntimeOptions;
import cucumber.runtime.RuntimeOptionsFactory;
import cucumber.runtime.io.MultiLoader;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.io.ResourceLoaderClassFinder;

public class QAFTestNGCucumberRunner {
	private final cucumber.runtime.Runtime runtime;

	/**
	 * Bootstrap the cucumber runtime
	 *
	 * @param clazz
	 *            Which has the cucumber.api.CucumberOptions and
	 *            org.testng.annotations.Test annotations
	 * @param contex
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public QAFTestNGCucumberRunner(Class clazz, ITestContext contex) {
		
		ClassLoader classLoader = clazz.getClassLoader();
		ResourceLoader resourceLoader = new MultiLoader(classLoader);

		RuntimeOptionsFactory runtimeOptionsFactory = new RuntimeOptionsFactory(clazz);
		RuntimeOptions runtimeOptions = runtimeOptionsFactory.create();
		getBundle().setProperty(QAFCucumberFormatter.SUITE_NAME, contex.getCurrentXmlTest().getSuite().getName());
		getBundle().setProperty(QAFCucumberFormatter.TEST_NAME, contex.getCurrentXmlTest().getName());

		runtimeOptions.getGlue().addAll(getBundle().getList("glue"));
		runtimeOptions.getFeaturePaths().addAll(getBundle().getList("features"));
		runtimeOptions.getFilters().addAll(getBundle().getList("tags"));
		//QAFPerfectoCucumberFormatter reporter = new QAFPerfectoCucumberFormatter(System.out);
		//runtimeOptions.addPlugin(reporter);
		runtimeOptions.formatter(classLoader);

		ClassFinder classFinder = new ResourceLoaderClassFinder(resourceLoader, classLoader);
		runtime = new cucumber.runtime.Runtime(resourceLoader, classFinder, classLoader, runtimeOptions);
	}

	/**
	 * Run the Cucumber features
	 */
	public void runCukes() {
		try {
			runtime.run();
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
		if (!runtime.getErrors().isEmpty()) {
			throw new CucumberException(runtime.getErrors().get(0));
		} else if (runtime.exitStatus() != 0x00) {
			throw new CucumberException("There are pending or undefined steps.");
		}
	}

}
